// 00:00:00
const s = document.querySelector(".sec")
const m = document.querySelector(".min")
const h = document.querySelector(".hour")

let sec = 0
let min = 0
let hour = 0
setInterval(() => {
    s.innerText = sec++
    
    if (sec < 11) {
        s.innerText = `0${sec}`
    }
 if (sec === 60) {
    sec = 0
    min++
    m.innerText = min
 }
 if (min === 60) {
    min = 0
    hour++
    h.innerText = hour
 }
}, 1)
